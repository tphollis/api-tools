This is a library that contains usefull functions to send API messages
and do some basic validation.

Using this library will help maintain consistent response formatting and
simplified coding for your API function.